package CT;
import databaseconnection.*;
import java.sql.*;

public class  GetData
{
static Connection con1=null;
static Statement st1=null;


public static String main(String id) {
	String res="";
try{

con1 = databasecon.getconnection();
st1 = con1.createStatement();
 String sql=null;;
sql="select * from questions where sno='"+id+"'";
ResultSet rs=null;
rs=st1.executeQuery(sql);

if(rs.next())
{
	res=rs.getString("qns").trim();
}
}
	catch(Exception e){
		System.out.println(e);
	}
	finally{
		try{
		con1.close();
		st1.close();
//		rs.close();
		}
		catch(Exception e){
		System.out.println(e);
		}
	}
	return res;
}

	
	public static void main(String[] args) 
	{
		System.out.println(main("1"));
	}

}



