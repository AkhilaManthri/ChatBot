package CT;

import java.util.Set;
import java.util.HashSet;
import java.io.File;
import java.io.PrintWriter;


import org.jsoup.Jsoup;
import org.jsoup.nodes.Document;
import org.jsoup.nodes.Element;
import org.jsoup.select.Elements;
 
public class bingSearch   {
 



  public static String  main(String args) {
	String result="";
	int  count=0;
	String key="";

	Document doc;
	try {
 
	boolean term=false; 
	String[] words=null;
	args=args.trim();
	words=args.split("\\s+");
	for(String s:words)
	{	
		if(term==true)
		{
					key=key+"+";
					key=key+s;
		}else{
			key=key+s;
		term=true;
		}
	}

	
		String first="11";
		String urlString = "http://www.bing.com/search?q="
                        + key;
		System.out.println(urlString);

		doc = Jsoup.connect(urlString).get();
		String title = doc.title();
		Elements links = doc.select("a[href]");




		for (Element link : links) {
 		String lk=link.attr("href");

		if((lk.contains("http://")||lk.contains("https://"))&&!lk.contains("microsoft")&&!lk.contains("msn"))
			{

			lk=lk.replaceAll("https://","");
			lk=lk.replaceAll("http://","");
			result=result+(++count)+": <a href=http://"+lk+" target=_blank>"+lk+"</a><br>";

			}

 
		}

 
	} catch (Exception e) {
		e.printStackTrace();
	}

return result; 
  }
  	public static void main(String[] args) 
	{
		System.out.println(main("java"));

	}

 
}