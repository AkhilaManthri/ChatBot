package CT;
import databaseconnection.*;
import java.sql.*;


public class InsertChatBot 
{

public static void main(String data,String user,String type ){ 
		
try{
	Connection con = databasecon.getconnection();
	PreparedStatement ps=con.prepareStatement("insert into msgs(msg,user_,time_,type_) values(?,?,?,?)");
	ps.setString(1,data);
	ps.setString(2,user);
	ps.setString(3,DateDemo.getTime());
		ps.setString(4,type);
	ps.executeUpdate();
	}
	catch(Exception e){
		System.out.println(e);
	}
	
	
}

public static void main2(String data, String email){ 
		
try{
	Connection con = databasecon.getconnection();
	PreparedStatement ps=con.prepareStatement("insert into suggetions(msg, email) values(?,?)");
	ps.setString(1,data);
	ps.setString(2,email);
	ps.executeUpdate();
	}
	catch(Exception e){
		System.out.println(e);
	}
	
	
}
	public static void main(String[] args) 
	{
		System.out.println("Hello World!");
	}
}
